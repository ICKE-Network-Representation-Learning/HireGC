#!/usr/bin/env python
# -*- coding: UTF-8 -*
from collections import defaultdict
from sklearn.preprocessing import MinMaxScaler, StandardScaler, normalize
import logging
import networkx as nx
import numpy as np
import scipy.sparse as sp
import sys
from graph import Graph
import random
from decimal import Decimal
import torch

def set_seed(seed, cuda):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if cuda: torch.cuda.manual_seed(seed)

def read_graph(ctrl, file_path, directed=False):
    '''Assume each edge shows up ONLY once: small-id<space>large-id, or small-id<space>large-id<space>weight. 
    Indices are not required to be continuous.'''
    in_file = open(file_path)
    neigh_dict = defaultdict(list)
    edge_num = 0
    for line in in_file:
        eles = line.strip().split()
        n0, n1 = [int(ele) for ele in eles[:2]]
        if len(eles) == 3: # weighted graph
            wgt = float(eles[2])
            neigh_dict[n0].append((n1, wgt))            
            if diercted ==False and n0 != n1:            
                neigh_dict[n1].append((n0, wgt))
        else:

            neigh_dict[n0].append(n1)
            if directed ==False and n0 != n1:
                neigh_dict[n1].append(n0)

        if directed ==False and n0 != n1:
            edge_num += 2
        else:
            edge_num += 1
       
    in_file.close()
    weighted = (len(eles) == 3)

    node_num = max(neigh_dict.keys())+1
    print(node_num ,edge_num ,weighted)

    graph = Graph(node_num, edge_num, weighted)
    edge_cnt = 0
    graph.adj_idx[0] = 0
    #check =open("check" ,'a+')
    for idx in range(node_num):
        graph.node_wgt[idx] = 1 # default weight to nodes
        for neigh in neigh_dict[idx]:
            if graph.weighted:
                graph.adj_list[edge_cnt] = neigh[0]
                graph.adj_wgt[edge_cnt] = neigh[1]
            else:
                graph.adj_list[edge_cnt] = neigh
                graph.adj_wgt[edge_cnt] = 1.0
            edge_cnt += 1
        graph.adj_idx[idx+1] = edge_cnt
    '''
    np.set_printoptions(threshold=np.inf)
    print(graph.adj_idx ,file= check)
    '''
    if ctrl.debug_mode:
       assert nx.is_connected(graph2nx(graph)), "Only single connected component is allowed for embedding."
 
    graph.A = graph_to_adj(graph, self_loop=False)
    graph.adj_matrix = graph_to_adj_matrix(graph, self_loop=False)
    graph.G= graph2nx(graph)
    return graph, weighted, node_num

def loadDataSet(filename):
    fr=open(filename)
    stringArr=[]
    line=fr.readline()
    while line:
          items = line.strip().split(' ')
          stringArr.append(items[1:])
          line=fr.readline()
    #stringArr=[line.strip().split('') for line in fr.readlines()]
    datArr=[list(map(float,line))for line in stringArr]
    return np.array(datArr)

def prepareData (filename, ratio=0.5): 
    f = open(filename +".edgelist",'rb')
    edges = [i for i in f]
    selected = int(len(edges) * float(ratio))
    selected = selected - selected % 128
    selected = random.sample(edges, selected)
    remain = [i for i in edges if i not in selected]
    fw1 = open(filename+".train", 'wb')
    fw2 = open(filename+".test", 'wb')

    for i in selected:
        fw1.write(i)
    for i in remain:
        fw2.write(i)
    fw1.close()
    fw2.close()
    return filename+".train", filename+".test"

def graph2nx(graph): # mostly for debugging purpose. weights ignored.
    G=nx.DiGraph()
    for idx in range(graph.node_num):
        for neigh_idx in range(graph.adj_idx[idx], graph.adj_idx[idx+1]):
            neigh = graph.adj_list[neigh_idx]
            wgt= graph.adj_wgt[neigh_idx]
            #if neigh>idx:
            if graph.weighted:
                G.add_edge(idx, neigh)
               
                G[idx][neigh]['weight'] = wgt
            else:
                G.add_edge(idx, neigh)
              
                G[idx][neigh]['weight'] = 1.0
  
    return G

def graph_to_adj(graph, self_loop=False):
    '''self_loop: manually add self loop or not'''
    node_num = graph.node_num
    i_arr = []
    j_arr = []
    data_arr = []
    for i in range(0, node_num):

        for neigh_idx in range(graph.adj_idx[i], graph.adj_idx[i+1]):
            i_arr.append(i)
            j_arr.append(graph.adj_list[neigh_idx])
            data_arr.append(graph.adj_wgt[neigh_idx])

    '''
    check = open("check", 'a+')
    np.set_printoptions(threshold=np.inf)
    print("1111111111111111", file=check)
    print("i_arr", i_arr, file=check)
    print("j_arr", j_arr, file=check)
    print("data_arr", data_arr, file=check)
    print(node_num)
    '''
    adj = sp.csr_matrix((data_arr, (i_arr, j_arr)), shape=(node_num, node_num), dtype=np.float32)
    if self_loop:
        adj = adj + sp.eye(adj.shape[0])
    return adj

def graph_to_adj_matrix(graph, self_loop=False):
    node_num = graph.node_num
    i_arr = []
    j_arr = []
    data_arr = []
    for i in range(0, node_num):
        for neigh_idx in range(graph.adj_idx[i], graph.adj_idx[i+1]):
            i_arr.append(i)
            j_arr.append(graph.adj_list[neigh_idx])
            data_arr.append(graph.adj_wgt[neigh_idx])

    adjacency_matrix = np.zeros((node_num, node_num))
    for i, j, data in zip(i_arr, j_arr, data_arr):
        if adjacency_matrix[i][j] == 0:
            adjacency_matrix[i][j] = data
        else:
            adjacency_matrix[j][i] = data  
    adj_tensor = torch.tensor(adjacency_matrix, dtype=torch.int)

    return adj_tensor


def cmap2C(cmap): # fine_graph to coarse_graph, matrix format of cmap: C: n x m, n>m.
    node_num = len(cmap)
    i_arr = []
    j_arr = []
    data_arr = []
    for i in range(node_num):
        i_arr.append(i)
        j_arr.append(cmap[i])
        data_arr.append(1)
    return sp.csr_matrix((data_arr, (i_arr, j_arr)))        

def setup_custom_logger(name):
    formatter = logging.Formatter(fmt='%(asctime)s %(levelname)-8s %(message)s',
                                  datefmt='%Y-%m-%d %H:%M:%S')
    screen_handler = logging.StreamHandler(stream=sys.stdout)
    screen_handler.setFormatter(formatter)
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(screen_handler)
    return logger

def normalized(embeddings, per_feature=True):
    if per_feature:
        scaler = MinMaxScaler()
        # scaler = StandardScaler()
        scaler.fit(embeddings)
        return scaler.transform(embeddings)
    else:
        return normalize(embeddings, norm='l2')
def get_trained_embedding(filepath):
    fr = open(filepath)
    line0 = fr.readline()
    item0 = line0.strip().split(' ')
    print("shape",item0)
    vector ={}
    line = fr.readline()
    while line:
        items = line.strip().split(' ')
        vector[int(items[0])] =[Decimal(x) for x in items[1:]]
        line = fr.readline()
    node_num = max(vector.keys()) + 1
    embeddings = np.zeros((node_num, 128))  # Dimensionm
    for node, vec in vector.items():
        embeddings[node] = vec

    return embeddings