'''1，首先获取粗图 
2，获取细图
3，将细图与粗图建立联联系，使用corsen里面的creat_newgraph 将细图与粗图建立链接
'''

#输入 细图graph ，以及粗图对应字典in_comm,
from collections import defaultdict
from utils import cmap2C ,graph2nx
import numpy as np
from graph import Graph
from attention import GATLayer
import random
import time
import networkx as nx
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.cluster import KMeans
import torch
import torch.nn as nn
from sklearn.cluster import MiniBatchKMeans
from collections import Counter
import random

def get_inductive_graph(lowDAttrMat_full,FUll_node_neighbour,Ind_index,inductive_graph,in_comm,label,weighted,embed_dim, match_method,k,coarsen_level,device): 
    inductive_graph.Attr = lowDAttrMat_full
    incomm = creat_newcomm(FUll_node_neighbour,Ind_index,in_comm,label,inductive_graph,weighted,lowDAttrMat_full,embed_dim,device)
    in_comm[0] = incomm
    inductive_coarsen_graph, inductive_graph = create_NewGraph(in_comm[0],inductive_graph)  
    #求加入新节点后的粗图的节点属性
    inductive_coarsen_graph.Attr = coarsen_Attr(in_comm[0], lowDAttrMat_full)
    print('inductive_coarsen_graph.Attr:',type(inductive_coarsen_graph.Attr),inductive_coarsen_graph.Attr.shape)
    for i in range(1,coarsen_level):
        #根据coarsen_level，新节点继续往里走
        AttrMat = inductive_coarsen_graph.Attr
        mbk = MiniBatchKMeans(init='k-means++', n_clusters=k, batch_size=125, n_init=10,
                              max_no_improvement=10, verbose=0, reassignment_ratio=0.001)
        mbk.fit(AttrMat)
        AttrMat, inductive_coarsen_graph, inductive_graph=create_coarsen_graph(attrmat=AttrMat, graph=inductive_coarsen_graph, in_comm = in_comm[i])
        inductive_coarsen_graph.Attr = AttrMat


    #根据粗图的属性向量和邻接矩阵求每个粗节点的特征
    # attention_attr = defaultdict(list)
    # my_GAT = GATLayer(embed_dim, 10, 0.2, 0.2)
    # #my_GAT.to(device)
    # # attention_attr = my_GAT.attention_weight(torch.tensor(inductive_coarsen_graph.Attr),  torch.tensor(inductive_coarsen_graph.A.todense()))
    # #attention_attr = my_GAT.attention_weight(torch.tensor(inductive_coarsen_graph.Attr).to(device), inductive_coarsen_graph.adj_matrix.to(device))
    # attention_attr = my_GAT.attention_weight(torch.tensor(inductive_coarsen_graph.Attr), inductive_coarsen_graph.adj_matrix)
    # #print("lalala: ", attention_attr[1])
    # #attention_attr = attention_attr.to('cpu')
    # coarsen_node_neighbour = get_node_neighbour(inductive_coarsen_graph.adj_matrix)
    # neighbour_cos = []
    # #遍历粗图所有节点，求其与邻居节点的余弦相似度(根据上一步求的特征)
    # # sum = 0
    # j = 0
    # for i in range(0, inductive_coarsen_graph.node_num):
    # #证明了coarsen_node_neighbour里的元素个数和inductive_coarsen_graph.adj_wgt的元素个数相等(一一对应？)
    # #     sum += len(coarsen_node_neighbour[i])
    # # if(sum==len(inductive_coarsen_graph.adj_wgt)):
    # #     print("hahahahahaha!")
    #     for ind in coarsen_node_neighbour[i]:
    #         #numpy数据下的余弦相似度
    #         #cos_sim = np.dot(attention_attr[i].detach().numpy(), attention_attr[ind].detach().numpy()) / (np.linalg.norm(attention_attr[i].detach().numpy()) * np.linalg.norm(attention_attr[ind].detach().numpy()))
    #         #tensor张量下的cos
    #         cos_sim = torch.cosine_similarity(attention_attr[i].detach(), attention_attr[ind].detach(), dim=0)
    #         cos_sim = torch.round(abs(cos_sim) * 1000) / 1000
    #         # if i == 100:
    #         #     print("hhhhh",cos_sim)
    #         inductive_coarsen_graph.adj_wgt[j] = cos_sim * inductive_coarsen_graph.adj_wgt[j]
    #         # inductive_coarsen_graph.adj_wgt[j] = round(abs(cos_sim),3) * inductive_coarsen_graph.adj_wgt[j]  #numpy数据保留小数点用round
    #         j += 1
    #         neighbour_cos.append(abs(cos_sim))
    # print("j=",j)
    # print("len(adj_wgt)=",len(inductive_coarsen_graph.adj_wgt))


    # print("inductive_graph.num:",inductive_graph.node_num)
    # print(inductive_graph.C.shape)
    #1修改in_comm，2然后将粗图与细图建立连接
    return inductive_coarsen_graph, inductive_graph


def get_node_neighbour(adj_matrix):
    node_neighbour = defaultdict(list)
    for i in range(adj_matrix.shape[0]):
        for j in range(adj_matrix.shape[1]):
            if adj_matrix[i][j] != 0:
                node_neighbour[i].append(j)
            # if i == j:
            #     pass
            # else:
            #     if adj_matrix[i][j] != 0:
            #         node_neighbour[i].append(j)
    return node_neighbour

def create_coarsen_graph(attrmat, graph,in_comm):
    c_mat=[]
    for c_node in in_comm.keys():
        c1_mat=[]
        c3_mat=None
        for ch_node in in_comm[c_node]:
            c1_mat.append(attrmat[ch_node])   
        c2_mat=np.array(c1_mat)
        c3_mat=np.mean(c2_mat,axis=0)
        c_mat.append(c3_mat)
    Attrmat=np.array(c_mat)

    NewGraph,graph=create_NewGraph(in_comm,graph)

    return Attrmat,NewGraph,graph



def coarsen_Attr(in_comm, lowDAttrMat_full):
    c_mat=[]
    for c_node in in_comm.keys():
        c1_mat=[]
        c3_mat=None
        for ch_node in in_comm[c_node]:
            c1_mat.append(lowDAttrMat_full[ch_node])   
        c2_mat=np.array(c1_mat)
        c3_mat=np.mean(c2_mat,axis=0)
        c_mat.append(c3_mat)
    Attrmat=np.array(c_mat)
    return Attrmat

def coarsen_Attr_citeseer(in_comm, lowDAttrMat_full):
    c_mat=[]
    for c_node in in_comm.keys():
        c1_mat=[]
        for ch_node in in_comm[c_node]:
            c1_mat.append(lowDAttrMat_full[ch_node])   
        c2_mat=np.array(c1_mat)
        c_mat.append(c2_mat)
    Attrmat=np.array(c_mat)
    return Attrmat

# def creat_newcomm(FUll_node_neighbour,Ind_index,in_comm,label,lowDAttrMat_full):
def creat_newcomm(FUll_node_neighbour,Ind_index,in_comm,label,inductive_graph,weighted,lowDAttrMat_full,embed_dim,device):
    #将in_comm 原先为{0,[1,2,3]},转换为{1:0,2:0,3:0}
    in_comm = community_transform(in_comm)
        # check = open("in_comm_rest_ind_index ", 'a+')
        # np.set_printoptions(threshold=np.inf)
        # print("rein_comm0:and len(rein_comm)\n", in_comm, len(in_comm), file=check)

    Ind_index = list(Ind_index)
    oldlength = 0
    print("lens:",len(in_comm))
    while oldlength != len(Ind_index):
        oldlength = len(Ind_index)
        for newnode in Ind_index:
            if Has_no_same_element(FUll_node_neighbour[newnode], Ind_index):
                #操作in_comm,对现有邻居全部有了社团归属的节点进行社团划分
                #in_comm , state = creat_node_community_cos(FUll_node_neighbour[newnode], newnode, in_comm,lowDAttrMat_full)
                in_comm , state = creat_node_community_attention(FUll_node_neighbour[newnode], newnode, in_comm,lowDAttrMat_full,embed_dim,device)
                #in_comm , state = creat_node_community_weight(FUll_node_neighbour[newnode], newnode, in_comm,inductive_graph,weighted)
                # in_comm, state = creat_node_community_random(FUll_node_neighbour[newnode], newnode, in_comm) 
                Ind_index.remove(newnode)
    print("lens:",len(in_comm))

    #对有环形成的节点，即，邻居有新节点存在，导致无法获取新节点全部社区分布需要单独处理
    #处理方式为，先对邻居多的节点打上标签，之后少邻居的节点跟上
    if Ind_index:
        rest_node_neighbour = {}
        for i in Ind_index:
            rest_node_neighbour[i] = FUll_node_neighbour[i]
        rest_node = sorted(rest_node_neighbour.items(), key=lambda x: len(x[1]), reverse=True)
        for newnode in rest_node:
            #in_comm ,state= creat_node_community_cos(newnode[1], newnode[0], in_comm,lowDAttrMat_full)
            in_comm ,state= creat_node_community_attention(newnode[1], newnode[0], in_comm,lowDAttrMat_full,embed_dim,device)
            #in_comm ,state= creat_node_community_weight(newnode[1], newnode[0], in_comm,inductive_graph,weighted)
            # in_comm, state = creat_node_community_random(newnode[1], newnode[0], in_comm)
            Ind_index.remove(newnode[0])
    print("lens:",len(in_comm))
    #对最后的孤立节点赋值，采用随机选取标签相似的节点社区
    '''check = open("in_comm_rest_ind_index ", 'a+')
    np.set_printoptions(threshold=np.inf)
    print("in_comm0:and len(in_comm)",in_comm, len(in_comm),file=check)
    print("Ind_index0:", Ind_index, file=check)'''
    num = len(label)
    if num >3310 and num <3400:
        num = 3327
        list1 = [3319, 3320, 3322, 3323]
        match= {3319:-8, 3320:-7, 3322:-5, 3323:-4}
        for node in list1:
            n = np.where(label==label[match[node]])
            r = random.randint(0,len(n[0])-1)
            com_id = n[0][r]
            in_comm[node] = in_comm[com_id]
    else :
        for i in range(num):
            if i not in in_comm.keys():
                Ind_index.append(i)
    print("lens:",len(in_comm))

    '''print("in_comm1:and len(in_comm)", in_comm, len(in_comm), file=check)
    print("Ind_index1:", Ind_index, file=check)'''
    while Ind_index:
        for node in Ind_index:
            n = np.where(label==label[node])
            r = random.randint(0,len(n[0])-1)
            com_id = n[0][r]
            in_comm[node] = in_comm[com_id]
            #print("restnode_com_id_in_comm[com_id]_in_comm[node]:",node,com_id,in_comm[com_id],in_comm[node] ,file=check)
            Ind_index.remove(node)
    print("lens:",len(in_comm))
    '''print("in_comm2:and len(in_comm)2", in_comm, len(in_comm), file=check)

    print("Ind_index2:",Ind_index, file=check)
    for i in Ind_index:
        print(i,FUll_node_neighbour[i],file=check)'''


    in_comm_final = defaultdict(list)
    for nodes ,comms in in_comm.items():
        in_comm_final[comms].append(nodes)
    print("len:", len(in_comm_final))

    return in_comm_final
#kmeans聚类归纳新节点
def creat_node_community_kmeans(node_neighbour, newnode, comms, features):
    state = 1
    neighbour_comm = defaultdict(list)
    for get_value in node_neighbour:
        if get_value in comms.keys():
            # 如果有邻居是新节点，即没有社区标签，则先忽略，即pass
            neighbour_comm[comms[get_value]].append(get_value)
        else:
            state = 0

    if len(neighbour_comm):
        # 使用K-means算法将新节点分配到一个簇中
        kmeans = KMeans(n_clusters=len(neighbour_comm)).fit(features[list(node_neighbour)])
        comms[newnode] = list(kmeans.labels_)[0]
    return comms, state
#用余弦相似度归纳新节点
def creat_node_community_cos(node_neighbour, newnode, comms, features):
    state = 1
    neighbour_cos = defaultdict(float) # 新建余弦相似度字典
    for get_value in node_neighbour:
        if get_value in comms.keys():
            # 计算余弦相似度并添加到字典neighbor_cos
            cos_sim = np.dot(features[get_value], features[newnode]) / (np.linalg.norm(features[get_value]) * np.linalg.norm(features[newnode]))
            neighbour_cos[comms[get_value]] += cos_sim  
        else:
            state = 0
    #找到余弦相似度最大的社区并将新节点加入
    if not neighbour_cos:
        pass
    else:
        max_cos_comm = max(neighbour_cos, key=neighbour_cos.get)
        comms[newnode] = max_cos_comm
    return comms, state
    #return max_cos_comm

#用注意力机制归纳新节点
def creat_node_community_attention(node_neighbour, newnode, comms, attr_mat, embed_dim,device):
    state = 1
    neighbour_comm = defaultdict(list)
    for get_value in node_neighbour:
        if get_value in comms.keys():
            # 如果有邻居是新节点，即没有社区标签，则先忽略，即pass
            neighbour_comm[comms[get_value]].append(get_value)
        else:
            state = 0

    if len(neighbour_comm):
        # 计算新节点与邻居节点的注意力系数
        attention_scores = {}
        my_GAT = GATLayer(embed_dim, 10, 0.2, 0.2)
        #my_GAT.to(device)
        #attr_mat = torch.from_numpy(attr_mat)
        #attr_mat = attr_mat.to(device)
        for comm, nodes in neighbour_comm.items():
            #e = my_GAT(attr_mat[newnode],attr_mat[nodes[0]]).item()
            e = my_GAT(torch.from_numpy(attr_mat[newnode]),torch.from_numpy(attr_mat[nodes[0]])).item()
            # attention_scores[comm] = abs(e)
            attention_scores[comm] = e

        # 将新节点放入注意力系数最大的社区
        max_comm = max(attention_scores, key=attention_scores.get)
        comms[newnode] = max_comm
    #return max_comm
    return comms, state

#根据权重归纳新节点
def creat_node_community_weight(node_neighbour,newnode, comms,graph, weighted):
    state = 1
    neighbour_comm = defaultdict(list)
    total_weight = 0
    for get_value in node_neighbour:
        if get_value in comms.keys():
            #如果有邻居是新节点，即没有社区标签，则先忽略，即pass
            neighbour_comm[comms[get_value]].append(get_value)
            if weighted == True:
                total_weight += graph.adj_wgt[graph.adj_idx[get_value]:graph.adj_idx[get_value+1]].sum()
            else:
                pass
        else:
            state = 0

    if len(neighbour_comm):
        ratios = {}
        if weighted == True:
            for comm, nodes in neighbour_comm.items():
                comm_weight = sum(graph.adj_wgt[graph.adj_idx[node]:graph.adj_idx[node+1]].sum() for node in nodes)
                ratios[comm] = comm_weight / total_weight
            max_ratio_comm = max(ratios, key=ratios.get)
            comms[newnode] = max_ratio_comm
        else:
            max_comm = sorted(neighbour_comm.items(), key=lambda x: len(x[1]), reverse=True)[0][0]
            comms[newnode] = max_comm
    #return max_comm
    return comms, state

def creat_node_community_random(node_neighbour, newnode, comms):
    state = 1
    neighbour_comm = defaultdict(list)
    for get_value in node_neighbour:
        if get_value in comms.keys():
            neighbour_comm[comms[get_value]].append(get_value)
        else:
            state = 0

    if len(neighbour_comm):
        # 随机选择一个邻居节点
        random_node = random.choice(list(neighbour_comm.keys()))
        comms[newnode] = comms[random_node]
    return comms, state


def Has_no_same_element (list1 ,list2) :
    for i in list1 :
        if i in list2:
            return False
    return True

def community_transform(comm):
    #原来的数据类型是{0: {0：[1,2,3]，1：[7,8]},1：{}}只转第一层的in_comm 有{1:0,2:0,3:0,7:1,8:1}
    comm_reverse ={}
    for key, vall in comm[0].items():
        for val in vall:
            comm_reverse[val] = key
    return comm_reverse

def graph_to_adj_matrix(graph):
    node_num = graph.node_num
    i_arr = []
    j_arr = []
    data_arr = []
    for i in range(0, node_num):
        for neigh_idx in range(graph.adj_idx[i], graph.adj_idx[i+1]):
            i_arr.append(i)
            j_arr.append(graph.adj_list[neigh_idx])
            data_arr.append(graph.adj_wgt[neigh_idx])

    adjacency_matrix = np.zeros((node_num, node_num))
    for i, j, data in zip(i_arr, j_arr, data_arr):
        if adjacency_matrix[i][j] == 0:
            adjacency_matrix[i][j] = data
        else:
            adjacency_matrix[j][i] = data  
    adj_tensor = torch.tensor(adjacency_matrix, dtype=torch.int)

    return adj_tensor

def create_NewGraph(in_comm, graph):
    #in_comm 数据格式为{0：[1,2,3],1:[4,5,6]}
    cmap = graph.cmap
    coarse_graph_size = 0
    for inc_idx in in_comm.keys():
        for ele in in_comm[inc_idx]:
            cmap[ele] = coarse_graph_size
        coarse_graph_size += 1
    newGraph = Graph(coarse_graph_size, graph.edge_num, weighted=True)
    newGraph.finer = graph
    graph.coarser = newGraph

    adj_list = graph.adj_list
    adj_idx = graph.adj_idx
    adj_wgt = graph.adj_wgt
    node_wgt = graph.node_wgt

    coarse_adj_list = newGraph.adj_list

    coarse_adj_idx = newGraph.adj_idx
    coarse_adj_wgt = newGraph.adj_wgt
    coarse_node_wgt = newGraph.node_wgt
    coarse_degree = newGraph.degree
    coarse_adj_idx[0] = 0
    nedges = 0  # number of edges in the coarse graph
    idx = 0

    for idx in range(len(in_comm)):  # idx in the graph
        coarse_node_idx = idx
        neigh_dict = dict()  # coarser graph neighbor node --> its location idx in adj_list.
        group = in_comm[idx]
        for i in range(len(group)):
            merged_node = group[i]
            if (i == 0):
                coarse_node_wgt[coarse_node_idx] = node_wgt[merged_node]
            else:
                coarse_node_wgt[coarse_node_idx] += node_wgt[merged_node]

            istart = adj_idx[merged_node]
            iend = adj_idx[merged_node + 1]
            for j in range(istart, iend):
                # print("j:",j)
                k = cmap[adj_list[j]]  # adj_list[j] is the neigh of v; k is the new mapped id of adj_list[j] in coarse graph.
                if k not in neigh_dict:  # add new neigh
                    coarse_adj_list[nedges] = k
                    coarse_adj_wgt[nedges] = adj_wgt[j]
                    neigh_dict[k] = nedges
                    nedges += 1
                else:  # increase weight to the existing neigh
                    coarse_adj_wgt[neigh_dict[k]] += adj_wgt[j]
                # add weights to the degree. For now, we retain the loop.

                coarse_degree[coarse_node_idx] += adj_wgt[j]

        coarse_node_idx += 1
        coarse_adj_idx[coarse_node_idx] = nedges

    newGraph.edge_num = nedges
    newGraph.G = graph2nx(newGraph)
    '''
    ne=0
    nelist=[]
    for edge in newGraph.G.edges(): 
        e=list(edge)
        i=e[0]
        j=e[1]   
        if edge not in nelist:
           nelist.append(edge)
           ne+=1
           nelist.append((j,i))
     '''

    print("newG_edges:", len(newGraph.G.edges()))

    newGraph.resize_adj(nedges)
    # newGraph.G=newG

    '''check = open("cmap", 'a+')
    np.set_printoptions(threshold=np.inf)
    print(cmap, file=check)
    print("len(cmap)", len(cmap), "max(cmap)", max(cmap), file=check)
    print("-1:",np.where(cmap==-1), file=check)'''

    C = cmap2C(cmap)  # construct the matching matrix.
    graph.C = C
    newGraph.A = C.transpose().dot(graph.A).dot(C)
    newGraph.adj_matrix = graph_to_adj_matrix(newGraph)
    return newGraph, graph

