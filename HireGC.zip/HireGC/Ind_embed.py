
'''

输入输出： 前1708个节点的embedding 后1000个节点的邻居图 全图属性向量
    步骤：1 查找新节点邻居邻居 及其embedding 如果邻居有未知节点 那就先不计算 即先找邻居embedding全部已知的计算

需要函数： 查找邻居 计算属性相似度 计算节点embedding
'''
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity


def Has_no_same_element (list1 ,list2) :
    for i in list1 :
        if i in list2:
            return False
    return True

nannode =0
def embedding_new_node(embeddings, node_neighbour, Attribute_dataMat ,newnode) :
    #feature = open("feature","a+")
    self_feature = Attribute_dataMat[newnode].reshape(1, Attribute_dataMat.shape[1])
    neighbour_feature_arry = Attribute_dataMat[node_neighbour]
    neighbour_embedding = embeddings[node_neighbour]
    #print("newnode",newnode,"self_feature.shape",self_feature.shape,"neighbour_feature_arry.shape",neighbour_feature_arry.shape,"node_neighbour",node_neighbour,file=feature)
    node_similarity = cosine_similarity(self_feature, neighbour_feature_arry)
    Normalized = node_similarity / np.sum(node_similarity)
    embeddings[newnode] = np.dot(Normalized, neighbour_embedding)

    return embeddings





def Ind_embed(embeddings, FUll_node_neighbour, Attribute_dataMat,Inductive_index):
    #直接计算
    Ind_index = list(Inductive_index)
    oldlength = 0
    count1 = 0
    while oldlength !=len(Ind_index):
        oldlength = len(Ind_index)
        for newnode in Ind_index:
            if Has_no_same_element(FUll_node_neighbour[newnode] ,Ind_index):
                Inductive_embed = embedding_new_node(embeddings, FUll_node_neighbour[newnode], Attribute_dataMat ,newnode)
                Ind_index.remove(newnode)
                count1 +=1
    #delete one neighbour!
    if Ind_index:
         print("测试节点有环形成")
         print(Ind_index.sort())
         Ind_dict ={}
         for i in Ind_index:
             Ind_dict[i] =FUll_node_neighbour[i]
         n_order = sorted(Ind_dict.items(), key=lambda x: len(x[1]), reverse=False)
         One_neigh =[]
         c =0
         for i ,item in n_order:
             if len(item) ==1:
                 One_neigh.append(i)
                 np.random.seed(i)
                 Ind_index.remove(i)
                 for j in range(Inductive_embed.shape[1]):
                     Inductive_embed[i][j] = np.random.uniform(-1, 1)

             else:
                Inductive_embed = embedding_new_node(Inductive_embed, FUll_node_neighbour[i], Attribute_dataMat, i)
                Ind_index.remove(i)
                c +=1

         print("One_neigh",One_neigh,len(One_neigh))


    print("count1+len(One_neigh)+c=",count1,"+",len(One_neigh),"+",c," =",count1+len(One_neigh)+c)
    print("remain:",Ind_index)
    zero = np.where((Inductive_embed == np.zeros(Inductive_embed.shape[1])).all(1))[0]
    print("zero", zero)
    print(len(zero))
    print("sum", len(zero) + count1 + len(One_neigh) + c)

    #Nan process

    print("Inductive NAN1 nodes:")
    nan = list({}.fromkeys(np.where(np.isnan(Inductive_embed))[0]).keys())
    print(nan)
    print(len(nan))
    print(Inductive_embed.shape)
    for i in nan:
        neighbour_embedding = Inductive_embed[FUll_node_neighbour[i]]
        Inductive_embed[i] = neighbour_embedding.mean(axis=0)

    nan = list({}.fromkeys(np.where(np.isnan(Inductive_embed))[0]).keys())
    print("After Mean:", nan)
    print(len(nan))
    print("nannode",nannode)
    nan_dict={}
    for i in nan:
        Inductive_embed[i] =np.zeros(embeddings.shape[1])
        nan_dict[i] = FUll_node_neighbour[i]
    n_order = sorted(nan_dict.items(), key=lambda x: len(x[1]), reverse=False)
    for i ,item in n_order:
        neighbour_embedding = Inductive_embed[FUll_node_neighbour[i]]
        Inductive_embed[i] = neighbour_embedding.mean(axis=0)

    nan = list({}.fromkeys(np.where(np.isnan(Inductive_embed))[0]).keys())
    print("After Last Mean:", nan)
    zero = np.where((Inductive_embed == np.zeros(Inductive_embed.shape[1])).all(1))[0]
    print("Last zero", zero)

    check1 = open("After Mean", 'a+')
    np.set_printoptions(threshold=np.inf)
    print("Zero Node :", zero, file=check1)
    print("Nan ", nan, file=check1)
    for i in zero:
        self_feature = Attribute_dataMat[i].reshape(1, Attribute_dataMat.shape[1])
        neighbour_feature_arry = Attribute_dataMat[FUll_node_neighbour[i]]
        node_similarity = cosine_similarity(self_feature, neighbour_feature_arry)
        Normalized = node_similarity / np.sum(node_similarity)
        neighbour_embedding = Inductive_embed[FUll_node_neighbour[i]]
        Inductive_embed[i] = neighbour_embedding.mean(axis=0)
        print(i, "neighbour", FUll_node_neighbour[i], "node_similarity", node_similarity, "Normalized", Normalized, " Inductive_embed[i]",Inductive_embed[i],
              "neighbour_embedding",neighbour_embedding,file=check1)

    zero = np.where((Inductive_embed == np.zeros(Inductive_embed.shape[1])).all(1))[0]
    print("Last zero", zero)

    pass

    return Inductive_embed











