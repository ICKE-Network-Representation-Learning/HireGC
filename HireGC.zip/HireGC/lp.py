from sklearn.metrics.pairwise import cosine_distances, cosine_similarity
import random
from sklearn.metrics import precision_recall_curve, auc, roc_curve, roc_auc_score, average_precision_score
import numpy as np
import matplotlib.pyplot as plt
from argparse import ArgumentParser, ArgumentDefaultsHelpFormatter
def sigmoid(x):
        x = np.clip(x, -500, 500)
        if x>=0:
            return 1.0/(1+np.exp(-x))
        else:
            return np.exp(x)/(1+np.exp(x))

def link_pred(filename, embeddings):
    Y_pred = []
    edge_exist = []
    count = 0
    with open(filename, 'r') as f:
        for line in f:
            start_entity, end_entity, edge_status = line.strip().split(" ")      
            if int(start_entity) in embeddings.keys() and int(end_entity) in embeddings.keys():   
                Y_pred.append((cosine_similarity([embeddings[int(start_entity)], embeddings[int(end_entity)]])[0][1] + 1.0) / 2.0)
                #Y_pred.append(np.dot(embeddings[int(start_entity)], embeddings[int(end_entity)]))
                edge_exist.append(int(edge_status))
            
            count += 1
    
    return edge_exist, Y_pred


   
def save_test(filename, y_test, y_score):     
    f = open(filename, 'w')
    for i in range(len(y_test)):
        f.write('{}\t{}\n'.format(y_test[i], y_score[i]))
    
    f.close()

def cal_auc(y_test, y_score):
    """
    calculate AUC value and plot the ROC curve
    """
    #fpr, tpr, threshold = roc_curve(y_test, y_score)
    roc_auc = roc_auc_score(y_test, y_score)
    #roc_score = roc_curve(y_test,y_score)
    #fpr, tpr, threshold = precision_recall_curve(y_test,y_score)
    ap=average_precision_score(y_test, y_score)
    # plt.figure()
    # plt.stackplot(fpr, tpr, color='steelblue', alpha = 0.5, edgecolor = 'black')
    # plt.plot(fpr, tpr, color='black', lw = 1)
    # plt.plot([0,1],[0,1], color = 'red', linestyle = '--')
    # plt.text(0.5,0.3,'ROC curve (area = %0.3f)' % roc_auc)
    # plt.xlabel('False Positive Rate')
    # plt.ylabel('True Positive Rate')
    # plt.show()

    return roc_auc, ap

def parse_args():
    parser = ArgumentParser(formatter_class=ArgumentDefaultsHelpFormatter,
                            conflict_handler='resolve')
   
    args = parser.parse_args()

    return args    

def lp(embeddings,test_file):
    args = parse_args()   

    Y_train, Y_train_pred = link_pred(test_file, embeddings)
    print(type(Y_train))
    print(len(Y_train ))
    #print("Y_train_pred ",Y_train )

    # save_test('lp_results.txt', Y_train, Y_train_pred)  
    return cal_auc(Y_train, Y_train_pred)
    
