import torch
import torch.nn as nn
import torch.nn.functional as F

class GATLayer(nn.Module):
    def __init__(self, in_features, out_features, dropout, alpha, concat=True,device = None):
        super(GATLayer, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.dropout = dropout
        self.alpha = alpha 
        self.device = device

        self.W = nn.Parameter(torch.zeros(size=(in_features, out_features)))
        nn.init.xavier_uniform_(self.W.data, gain=1.414)
        self.a = nn.Parameter(torch.zeros(size=(2 * out_features, 1)))
        nn.init.xavier_uniform_(self.a.data, gain=1.414)

        self.leakyrelu = nn.LeakyReLU(self.alpha)

    def forward(self, input_h, input_h_neigh):
        h1 = torch.matmul(input_h.double(), self.W.double())
        h2 = torch.matmul(input_h_neigh.double(), self.W.double())
        input_concat = torch.cat((h1.unsqueeze(0),h2.unsqueeze(0)),dim=1)
        #e = self.leakyrelu(torch.matmul(input_concat.double(), self.a.double()).squeeze(2))
        e = self.leakyrelu(torch.matmul(input_concat.double(), self.a.double()).unsqueeze(0))
        return e
    def attention_weight(self, input_h, adj):
        h = torch.mm(input_h.double(), self.W.double())
        N = h.size()[0]
        input_concat = torch.cat([h.repeat(1,N).view(N*N, -1),h.repeat(N, 1)],dim=1).view(N, -1, 2*self.out_features)
        e = self.leakyrelu(torch.matmul(input_concat.double(), self.a.double()).squeeze(2))
        zero_vec = -1e12*torch.ones_like(e)
        attention = torch.where(adj>0,e,zero_vec)
        attention = F.softmax(attention, dim=1)
        attention = F.dropout(attention, self.dropout, training = self.training)
        output_h = torch.matmul(attention, h)
        return output_h
