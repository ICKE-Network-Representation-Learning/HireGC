# -*- coding: UTF-8 -*
import time
import tensorflow as tf
from coarsen import create_coarse_graph
from utils import normalized, graph_to_adj
from numpy import *
import numpy as np
#from get_inductive_graph_citeseer import *
from get_inductive_graph import *
from sklearn.decomposition import PCA
from sklearn.cluster import MiniBatchKMeans
#打印每个粗化层级的节点数和层级信息
def print_coarsen_info(ctrl, g):
    cnt = 0
    while g is not None:
        ctrl.logger.info("Level " + str(cnt) + " --- # nodes: " + str(g.node_num))
        g = g.coarser
        cnt += 1


def multilevel_embed(ctrl, graph, match_method, basic_embed, refine_model, AttrMat,AttrMat_full,FUll_node_neighbour,Ind_index,inductive_graph,label,weighted,embed_dim,device):
    '''This method defines the multilevel embedding method.'''

    #start = time.time()
    # Step-1: Graph Coarsening.

    original_graph = graph
    stru_comms = {}
    comms={}

    graph.Attr=AttrMat
    print("graph.Attr", graph.Attr.shape)
    coarsen_level = ctrl.coarsen_level
    
    if ctrl.refine_model.double_base:  # if it is double-base, it will need to do one more layer of coarsening
        coarsen_level += 1
    print("coarsen_level:" + str(coarsen_level ))
    print("ctrl.k",ctrl.k)
    for i in range(coarsen_level):        
        time_start = time.time()
        #属性聚类
        #mbk = MiniBatchKMeans(init='k-means++', n_clusters=ctrl.k, batch_size=125, n_init=10,
        #                      max_no_improvement=10, verbose=0, reassignment_ratio=0.001)
        mbk = MiniBatchKMeans(init='k-means++', n_clusters=ctrl.k, batch_size=125, n_init=10,
                              max_no_improvement=10, verbose=0, reassignment_ratio=0.001)
        mbk.fit(AttrMat)
        labels = mbk.labels_
        attr_comms = [[] for j in range(ctrl.k)]
        #将属性打上层次信息如节点一在第0层，那他在attr_comms里面标上0
        il = 0
        for item in labels:
            attr_comms[item].append(il)
            il += 1

        time_end = time.time()
        print('kmeans totally cost', time_end - time_start)
        #结构聚类返回：结构id和节点社区
        stru_comms[i] = match_method(graph)
        #创建结构与属性融合

      

        AttrMat, coarse_graph, comms[i]=create_coarse_graph(stru_comms=stru_comms[i], attr_comms=attr_comms, attrmat=AttrMat, graph=graph)
        #返回属性粗化
        coarse_graph.Attr=AttrMat
        print(" coarse_graph.Attr.shape", coarse_graph.Attr.shape)
        # 结构粗化图

        graph = coarse_graph


    if ctrl.debug_mode and graph.node_num < 1e3:
        assert np.allclose(graph_to_adj(graph).A, graph.A.A), "Coarser graph is not consistent with Adj matrix"
    print_coarsen_info(ctrl, original_graph)
    print("coarse ok")

    # Step-2 : Base Embedding(应该可以不要)
    if ctrl.refine_model.double_base:
        graph = graph.finer     
    embedding = basic_embed(ctrl, graph)
    print('type(embedding):',type(embedding),embedding.shape)
    print('type(graph.Attr):', type(graph.Attr),graph.Attr.shape)
    #(line 65-79)for structure-only network embedding methods.
    embedding=concatenate((0.5*embedding, graph.Attr),axis=1) 
    
    if graph.node_num < ctrl.embed_dim:
       m=ctrl.embed_dim / graph.node_num
       embeddings=embedding 
       for i in range (m):
           embeddings=concatenate((embeddings, embedding),axis=0)
       pca = PCA(n_components=ctrl.embed_dim)
       pca.fit(embeddings)
       embeddings=pca.fit_transform(embeddings)
       embedding=embeddings[ : graph.node_num, : ]      
    else:   
       pca = PCA(n_components=ctrl.embed_dim)
       pca.fit(embedding)
       embedding=pca.fit_transform(embedding)

    print("embedding.shape",embedding.shape)
    
    print("Base Embedding ok")

    # Step - 3: Embeddings Refinement.(train over 前面也可以不要)
    if ctrl.refine_model.double_base:
        coarse_embed = basic_embed(ctrl, graph.coarser)
        coarse_embed = normalized(coarse_embed, per_feature=False)
    else:
        coarse_embed = None
    with tf.Session(config=tf.ConfigProto(intra_op_parallelism_threads=ctrl.workers)) as session:
        model = refine_model(ctrl, session)
        model.to(device)
        print(type(graph.coarser),type(graph),type(coarse_embed),type(embedding))
        model.train_model(coarse_graph=graph.coarser, fine_graph=graph, coarse_embed=coarse_embed,
                         fine_embed=embedding)  # refinement model training
        coarse_embed = None
        coarse_graph = None
        while graph.finer is not None:  # apply the refinement model.
            coarse_embed = embedding
            coarse_graph = graph
            embedding= model.refine_embedding(coarse_graph=graph, fine_graph=graph.finer, coarse_embed=embedding)
            graph = graph.finer

        print("train over !!! and train embedding shape is ", embedding.shape,"coarse_embed shape is",coarse_embed.shape)
        
        k = ctrl.k
        start_ind = time.time()
        #这里可以看作学习节点嵌入前的初始化（网络预处理）（网络微调）
        coarse_graph, fine_graph = get_inductive_graph(AttrMat_full, FUll_node_neighbour, Ind_index, inductive_graph, 
                                                       comms,label,weighted,embed_dim, match_method,k,coarsen_level,device)
        #coarsen_graph得给个Attr
        embedding = basic_embed(ctrl, coarse_graph)
        embedding=concatenate((0.5*embedding, coarse_graph.Attr),axis=1)
        pca = PCA(n_components=ctrl.embed_dim)
        pca.fit(embedding)
        embedding=pca.fit_transform(embedding)
        coarse_embed = embedding
            #print("fine_graph.cmap",fine_graph.C,file=check1)
        random = False
        if random:
            # 随机赋值上层节点 消融实验1做上层节点随机赋值卷
            for i in range(coarse_embed.shape[0]):
                np.random.seed(i + coarse_embed.shape[0])
                for j in range(coarse_embed.shape[1]):
                    coarse_embed[i][j] = np.random.uniform(-1, 1)

        evaluateE = False
        initial = False   
        # embedding = model.refine_embedding(coarse_graph=coarse_graph, fine_graph=fine_graph,
        #                                     coarse_embed=coarse_embed, initial=initial,
        #                                     evaluateE = evaluateE, evaluateEmbedding = ctrl.evaluateEmbedding)
        #start_ind = time.time()
        embedding = model.refine_embedding(coarse_graph=coarse_graph, fine_graph=fine_graph,
                                            coarse_embed=coarse_embed, initial=initial,
                                            evaluateE = evaluateE, evaluateEmbedding = None)
        while coarsen_level >= 2:
            coarse_graph = coarse_graph.finer
            coarse_embed = embedding
            fine_graph = coarse_graph.finer
            coarsen_level = coarsen_level - 1
            # embedding = model.refine_embedding(coarse_graph=coarse_graph, fine_graph=fine_graph,
            #                                         coarse_embed=coarse_embed, initial=initial,
            #                                         evaluateE = evaluateE, evaluateEmbedding = ctrl.evaluateEmbedding)
            embedding = model.refine_embedding(coarse_graph=coarse_graph, fine_graph=fine_graph,
                                                    coarse_embed=coarse_embed, initial=initial,
                                                    evaluateE = evaluateE, evaluateEmbedding = None)
        print("inductive over ！！！and indctive embedding shape is ", embedding.shape,"initial=",initial)
        end_ind = time.time()
        print("inductive time is ",end_ind-start_ind)

    #end = time.time()
    #ctrl.embed_time = end - start
    print("Embedding refinement ok")
    #print("times:",ctrl.embed_time)
    return embedding

