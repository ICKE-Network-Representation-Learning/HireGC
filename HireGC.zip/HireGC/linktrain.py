#!/usr/bin/env python
# -*- coding: UTF-8 -*
from argparse import ArgumentParser, ArgumentDefaultsHelpFormatter
from lv import louvainModularityOptimization
from defs import Control
from embed import multilevel_embed
from eval_embed import eval_multilabel_clf
from refine_model import GCN, GraphSage
from lputils import read_graph, setup_custom_logger,loadDataSet, prepareData,read_node,normalized
import importlib
import logging
import numpy as np
import tensorflow as tf
from classification import node_classification_F1, read_label
from sklearn.decomposition import PCA
from lp import *

def parse_args():
    parser = ArgumentParser(formatter_class=ArgumentDefaultsHelpFormatter,
                            conflict_handler='resolve')
    parser.add_argument('--data', required=False, default='/cora',
                        help='Input graph file')
    parser.add_argument('--format', required=False, default='edgelist', choices=['metis', 'edgelist'],
                        help='Format of the input graph file (metis/edgelist)')
    parser.add_argument('--store-embed', action='store_true',
                        help='Store the embeddings.')
    parser.add_argument('--no-eval', action='store_true',
                        help='Evaluate the embeddings.')
    parser.add_argument('--embed-dim', default=128, type=int,
                        help='Number of latent dimensions to learn for each node.')
    parser.add_argument('--basic-embed', required=False, default='deepwalk',
                        choices=['deepwalk', 'grarep', 'netmf'],
                        help='The basic embedding method. If you added a new embedding method, please add its name to choices')
    parser.add_argument('--refine-type', required=False, default='MD-gcn',
                        choices=['MD-gcn', 'MD-dumb', 'MD-gs'],
                        help='The method for refining embeddings.')
    parser.add_argument('--coarsen-level', default=2, type=int,
                        help='MAX number of levels of coarsening.')
    parser.add_argument('--workers', default=4, type=int,
                        help='Number of workers.')
    parser.add_argument('--double-base', action='store_true',
                        help='Use double base for training')
    parser.add_argument('--learning-rate', default=0.001, type=float,
                        help='Learning rate of the refinement model')
    parser.add_argument('--self-weight', default=0.05, type=float,
                        help='Self-loop weight for GCN model.')  # usually in the range [0, 1]
    # Consider increasing self-weight a little bit if coarsen-level is high.
    parser.add_argument('--directed',
                        default=False,
                        action='store_true',
                        help='treat graph as directed')           
    parser.add_argument('--ratio', default=0.8,type= float,
                        help='the train ratio for Link Prediction ')
    args = parser.parse_args()
    return args


def set_control_params(ctrl, args, graph):
    ctrl.refine_model.double_base = args.double_base
    ctrl.refine_model.learning_rate = args.learning_rate
    ctrl.refine_model.self_weight = args.self_weight

    ctrl.coarsen_level = args.coarsen_level
    ctrl.coarsen_to = max(1, graph.node_num // (2 ** ctrl.coarsen_level))  # rough estimation.
    ctrl.embed_dim = args.embed_dim
    ctrl.basic_embed = args.basic_embed
    ctrl.refine_type = args.refine_type
    ctrl.data = args.data                                                                
    ctrl.workers = args.workers
    ctrl.max_node_wgt = int((5.0 * graph.node_num) / ctrl.coarsen_to)
    ctrl.logger = setup_custom_logger('MANE')

    if ctrl.debug_mode:
        ctrl.logger.setLevel(logging.DEBUG)
    else:
        ctrl.logger.setLevel(logging.INFO)
    ctrl.logger.info(args)


def read_data(ctrl, args):
    prefix = "./dataset" + args.data + args.data
    input_edge_path=prefix + ".edgelist"
    input_attr_path=prefix + ".features"
    tarin_graph_path, test_graph_path =prepareData(prefix, args.ratio)
    y=read_label(prefix + ".label")
    ctrl.k = len(set(y))
    print("ctrl.k",ctrl.k)
    train_node=read_node(tarin_graph_path, directed=args.directed)
    
    graph,look_back,look_up= read_graph(ctrl, tarin_graph_path, directed=args.directed) 
    
    dataMat=loadDataSet(input_attr_path)
    #dataMat=np.load(input_attr_path)
    #dataMat = normalized(dataMat, per_feature=False)
    pca = PCA(n_components=ctrl.embed_dim)
    pca.fit(dataMat)#训练
    lowDAtrrMat1=pca.fit_transform(dataMat)#降维后的数据
    
    lowDAtrr={}
    for node in look_back:
        lowDAtrr[look_up[node]]=lowDAtrrMat1[node]
    lowDAtrrMat=[]
    for ii in range(len(lowDAtrr)):
         lowDAtrrMat.append(lowDAtrr[ii])
    
    lowDAtrrMat=np.array(lowDAtrrMat)   
 
    print("lowDAtrr.shape",lowDAtrrMat.shape)
    
    return tarin_graph_path,test_graph_path, graph, lowDAtrrMat,look_back,train_node

def select_base_embed(ctrl):
    mod_path = "base_embed_methods." + ctrl.basic_embed
    embed_mod = importlib.import_module(mod_path)
    embed_func = getattr(embed_mod, ctrl.basic_embed)
    return embed_func


def select_refine_model(ctrl):
    refine_model = None
    if ctrl.refine_type == 'MD-gcn':
        refine_model = GCN
    elif ctrl.refine_type == 'MD-gs':
        refine_model = GraphSage
    elif ctrl.refine_type == 'MD-dumb':
        refine_model = GCN
        ctrl.refine_model.untrained_model = True
    return refine_model



if __name__ == "__main__":
    seed = 2019
    np.random.seed(seed)
    tf.set_random_seed(seed)
    
    ctrl = Control()
    args = parse_args()
   
    # Read input graph
    tarin_graph_path,test_graph_path, graph, lowDAttrMat,look_back,train_node= read_data(ctrl, args)
    print("read ok")
    set_control_params(ctrl, args, graph)
    print("set ctrl ok")
   
    # Coarsen method
    match_method = louvainModularityOptimization

    # Base embedding
    basic_embed = select_base_embed(ctrl)

    # Refinement model
    refine_model = select_refine_model(ctrl)

    # Generate embeddings
    embeddings = multilevel_embed(ctrl, graph, match_method=match_method, basic_embed=basic_embed,
                                 refine_model=refine_model, AttrMat=lowDAttrMat)

    embeddings=np.concatenate((embeddings,lowDAttrMat),axis=1)
    pca = PCA(n_components=ctrl.embed_dim)
    pca.fit(embeddings)
    embeddings=pca.fit_transform(embeddings)

    embedding1={}
    for node in range(len(embeddings)):
        embedding1[look_back[node]]=embeddings[node]

    embedding={}
    for i in train_node: 
        embedding[i]=embedding1[i]

    print("embedding.shape",len(embedding))
    roc_auc,ap_score=lp(embedding,test_graph_path)
    print("roc_auc:",roc_auc)
    print("ap_score:",ap_score)
